//
//  AppID.swift
//  Agora iOS Voice Tutorial
//
//  Created by GongYuhua on 2017/4/10.
//  Copyright © 2017年 Agora. All rights reserved.
//

let AppID: String = <#Your App Id#>
// assign Token to nil if you have not enabled app certificate
let Token: String? = <#Temp Access Token#>
