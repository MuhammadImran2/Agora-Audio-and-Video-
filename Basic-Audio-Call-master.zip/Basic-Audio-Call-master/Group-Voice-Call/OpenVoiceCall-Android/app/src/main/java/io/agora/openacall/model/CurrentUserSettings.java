package io.agora.openacall.model;

public class CurrentUserSettings {
    public String mChannelName;

    public CurrentUserSettings() {
        reset();
    }

    public void reset() {
    }
}
