//
//  ChannelNameCheck.h
//  OpenVoiceCall-OC
//
//  Created by CavanSu on 2017/9/18.
//  Copyright © 2017 Agora. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ChannelNameCheck : NSObject
+ (NSString *)channelNameCheckLegal:(NSString *)channelName;
@end
