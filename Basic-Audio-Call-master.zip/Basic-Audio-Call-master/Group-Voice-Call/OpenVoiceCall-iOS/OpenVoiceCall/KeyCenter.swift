//
//  KeyCenter.swift
//  LargeGroupVideoChat
//
//  Created by ZhangJi on 30/09/2017.
//  Copyright © 2017 Agora. All rights reserved.
//

struct KeyCenter {
    static let AppId: String = <#Your App Id#>

    // assign token to nil if you have not enabled app certificate
    static var Token: String? = <#Temp Access Token#>
}
