rm -rf *.xcarchive
rm -f *.ipa
rm -rf *.app
rm -f DistributionSummary.plist
rm -f ExportOptions.plist
rm -f Packaging.log