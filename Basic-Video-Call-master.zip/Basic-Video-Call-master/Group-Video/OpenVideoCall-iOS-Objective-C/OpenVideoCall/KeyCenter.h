//
//  KeyCenter.h
//  OpenVideoCall
//
//  Created by GongYuhua on 2016/9/12.
//  Copyright © 2016年 Agora. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KeyCenter : NSObject
+ (NSString *)AppId;
+ (NSString *)Token;
@end
