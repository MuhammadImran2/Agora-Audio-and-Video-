//
//  KeyCenter.swift
//  OpenVideoCall
//
//  Created by GongYuhua on 5/16/16.
//  Copyright © 2016 Agora. All rights reserved.
//

struct KeyCenter {
    static let AppId: String = <#Your App Id#>
    // assign token to nil if you have not enabled app certificate
    static var Token: String? = <#Temp Access Token#>
}
